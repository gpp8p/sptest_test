<?php


namespace App\Classes;


class HeadlineCard
{

}
