<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ViewType extends Model
{
    //
}
